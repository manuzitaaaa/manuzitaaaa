function setup() {
  createCanvas(400, 400);
}
let olhoX;
let olhoY;

function draw() {
  background("#purple");
  fill("pink");
  circle(200, 200, 300); // rosto
  fill("white");
  circle(120, 150, 100); // olho esquerdo
  circle(280, 150, 100); // olho direito
  line(150, 270, 250, 235); // boca
  fill("black");
  // circle(150,150,10); // pupila esquerda
  //circle(250,150,10); // pupila direita

  olhoX = map(mouseX, 0, 400, 130, 170);
  olhoY = map(mouseY, 0, 400, 130, 170);

  circle(olhoX, olhoY, 50); // nova pupila esquerda
  circle(olhoX + 150, olhoY, 50); //nova pupila direita
  if (mouseIsPressed) {
    console.log(mouseX, mouseY);
    }
}
